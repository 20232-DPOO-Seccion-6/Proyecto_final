@Test
	public void CrearReserva() {
		
		Conductor conductorPrincipal = new Conductor("Sergio Molina","1223334444","15","Colombia","02/11/2030","path_imagen"
				,"3204558445","correo@gmail");
		Categoria cat = null;
		Carro vehiculoArrendado = new Carro("WKG009", "Chevrolet","2017","amarillo","manual",cat,"Salitre","-","activo",0.0f);
		ClienteNormal cliente = null;
		
		Reserva reserva = new Reserva(null, "02/02/2023", "02/03/2023", conductorPrincipal,vehiculoArrendado,cliente,
				false, "Salitre", "Norte", "activa");
				assertNotNull(reserva);
				assertEquals("02/02/2023", reserva.getFechaInicio());
				assertEquals("02/03/2023", reserva.getFechaFin());
				assertEquals(conductorPrincipal, reserva.getConductor());
				assertEquals(vehiculoArrendado, reserva.getVehiculoArrendado());
				assertEquals(cliente, reserva.getCliente());
				assertFalse(reserva.isPagada());
				assertEquals("Salitre", reserva.getOrigen());
				assertEquals("Norte", reserva.getDestino());
				assertEquals("activa", reserva.getEstado());
		
	}