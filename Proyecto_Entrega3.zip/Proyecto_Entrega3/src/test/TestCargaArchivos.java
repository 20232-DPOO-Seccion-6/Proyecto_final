package test;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Map;

import org.junit.Test;

import modelo.Carro;
import modelo.Categoria;
import modelo.ClienteNormal;
import modelo.Conductor;
import modelo.EmpresaVehiculos;
import modelo.Otros;
import modelo.Reserva;
import modelo.Sede;
import modelo.Seguro;
import modelo.Usuario;

public class TestCargaArchivos {
	//Atributos
	
	
	@Test
	public void CargasReservas() throws IOException {
		Usuario userAdmin = new Usuario("dlmanrique","1234","adminGeneral");
		EmpresaVehiculos empresa = new EmpresaVehiculos("Car Rental", "Leonardo Manrique", "1001168408", userAdmin);
		
		empresa.cargarSedes(new File("./data/sedes.txt"));
		ArrayList<Sede> sedes = empresa.getSedes();
		assertNotNull(sedes);
        assertTrue(sedes.size() > 0);
        
        empresa.cargarCategorias(new File("./data/categorias.txt"));
        Map<String, Categoria> categorias = empresa.getCategorias();
        assertFalse(categorias.isEmpty());
        
        empresa.cargarVehiculos(new File("./data/vehiculos.txt"));
        Map<String, ArrayList<Carro>> vehiculos = empresa.getSedes().get(2).getInventario().getVehiculos();
        assertFalse(vehiculos.isEmpty());
        
		empresa.cargarReservas(new File("./data/reservas.txt"));
		Map<String, Reserva> reservas = empresa.getReservas();
		assertFalse(reservas.isEmpty());
	}
	
	@Test
	public void CargasExtra() throws IOException {
		Usuario userAdmin = new Usuario("dlmanrique","1234","adminGeneral");
		EmpresaVehiculos empresa = new EmpresaVehiculos("Car Rental", "Leonardo Manrique", "1001168408", userAdmin);
		
		empresa.cargarClientes(new File("./data/clientes.txt"));
		Map<String, ClienteNormal> clientes = empresa.getClientes();
		assertFalse(clientes.isEmpty());
		
		empresa.cargarConductores(new File("./data/conductores.txt"));
		Map<String, Conductor> conductores = empresa.getConductores();
		assertFalse(conductores.isEmpty());
		
		empresa.cargarSeguros(new File("./data/seguros.txt"));
		ArrayList<Seguro> seguros = empresa.getSeguros();
		assertNotNull(seguros);
        assertTrue(seguros.size() > 0);
		
		empresa.cargarOtros(new File("./data/otros.txt"));
		ArrayList<Otros> otros = empresa.getOtros();
		assertNotNull(otros);
        assertTrue(otros.size() > 0);
		
		empresa.cargarUsuarios(new File("./data/usuarios.txt"));
		ArrayList<Usuario> usuarios = empresa.getUsuarios();
		assertNotNull(usuarios);
        assertTrue(usuarios.size() > 0);		
		
	}

}
