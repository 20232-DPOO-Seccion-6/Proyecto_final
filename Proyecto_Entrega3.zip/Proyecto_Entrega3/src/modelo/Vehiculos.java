package modelo;

public interface Vehiculos {

}
