package modelo;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class Sire extends Pasarela{
	//Atributos
	private String numeroTarjeta;
	private String numeroSeguridad;
	private String fechaVencimiento;
	private String idReserva;
	
	public Sire() {
		
	}

	public String getNumeroTarjeta() {
		return numeroTarjeta;
	}

	public String getNumeroSeguridad() {
		return numeroSeguridad;
	}

	public String getFechaVencimiento() {
		return fechaVencimiento;
	}

	public void setNumeroTarjeta(String numeroTarjeta) {
		this.numeroTarjeta = numeroTarjeta;
	}

	public void setNumeroSeguridad(String numeroSeguridad) {
		this.numeroSeguridad = numeroSeguridad;
	}

	public void setFechaVencimiento(String fechaVencimiento) {
		this.fechaVencimiento = fechaVencimiento;
	}
	
	
	public String getIdReserva() {
		return idReserva;
	}

	public void setIdReserva(String idReserva) {
		this.idReserva = idReserva;
	}

	public boolean validarPago(Tarjeta tarjeta) {
		this.numeroSeguridad = tarjeta.getCodigoSeguridadTarjeta();
		this.numeroTarjeta = tarjeta.getNumeroTarjeta();
		if (numeroTarjeta.length() == 0 || numeroSeguridad.length() == 0) {
			return false;
		}
		else {
			return true;
		}
	}
	
	public void guardarPago(Tarjeta tarjeta, String idReserva, String porcentaje, String total) throws IOException {
		this.numeroSeguridad = tarjeta.getCodigoSeguridadTarjeta();
		this.numeroTarjeta = tarjeta.getNumeroTarjeta();
		
		String texto = "\n" + idReserva + ";" +  numeroTarjeta + ";" + numeroSeguridad + ";" + porcentaje + ";" + total;
		FileWriter fileWriter = new FileWriter("./data/Sire.txt", true);
        BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
        bufferedWriter.write(texto);
        bufferedWriter.close();
	}
}
