package modelo;

import java.io.IOException;

public abstract class Pasarela {
	public abstract void guardarPago(Tarjeta tarjeta, String idReserva, String porcentaje, String total) throws IOException;
	public abstract boolean validarPago(Tarjeta tarjeta);
}
