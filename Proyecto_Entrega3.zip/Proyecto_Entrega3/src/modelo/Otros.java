package modelo;

public class Otros implements Vehiculos{
	//Atributos
	private String Id;
	private String color;
	private String tipo;
	private float porcentaje;
	private String sede;
	
	//Metodos
	public Otros(String color, String Id, String tipo, float porcentaje, String sede) {
		this.color = color;
		this.sede = sede;
		this.Id = Id;
		this.tipo = tipo;
		this.porcentaje = porcentaje;
	}

	public String getColor() {
		return color;
	}

	public String getId() {
		return Id;
	}

	public String getTipo() {
		return tipo;
	}

	public float getPorcentaje() {
		return porcentaje;
	}

	public String getSede() {
		return sede;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public void setId(String id) {
		Id = id;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public void setPorcentaje(float porcentaje) {
		this.porcentaje = porcentaje;
	}

	public void setSede(String sede) {
		this.sede = sede;
	}
	
	
}
