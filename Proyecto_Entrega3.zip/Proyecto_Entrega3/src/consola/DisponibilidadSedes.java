package consola;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Random;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import modelo.EmpresaVehiculos;
import modelo.Sede;

@SuppressWarnings("serial")
public class DisponibilidadSedes extends JPanel implements ActionListener{
	//Atributos 
	@SuppressWarnings("unused")
	private EmpresaVehiculos empresa;
	private String fecha1;
	private String fecha2;
	private String sede;
	
	// Constantes asociadas a eventos
	public final static String CONSULTA = "Consulta";
		
		
	// Atributos asociados a botones de interacci�n
	private JButton consultaButton;
	
	
	//Metodos
	public DisponibilidadSedes(EmpresaVehiculos empresa) {
		this.empresa = empresa;
		
		setLayout(new BorderLayout());
		
		Color colorFondo = new Color(184, 185, 187);
		Color grisCasiBlanco = new Color(220,220,220);
		Color rojoOscuro = new Color(184, 25, 25);
		Font fontMonserratBold = new Font("Monserrat", Font.BOLD, 20);
		Font fontBotones = new Font("Arial", Font.PLAIN, 15);
		
		JPanel total = new JPanel();
		total.setLayout(null);
		total.setBackground(colorFondo);
		
		JPanel infoSedes = new JPanel();
		infoSedes.setLayout(new GridBagLayout());
		infoSedes.setOpaque(true);
		infoSedes.setBackground(grisCasiBlanco);
		infoSedes.setBounds(200, 10, 450, 400);
		GridBagConstraints gbc = new GridBagConstraints();
		gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5, 5, 5, 5);
		
		JLabel titleLabel = new JLabel("<html> Consultar inventario en una <br> sede para ciertas fechas </html>");
        titleLabel.setFont(fontMonserratBold);
        gbc.gridx = 0;
        gbc.gridy = 0;
        infoSedes.add(titleLabel, gbc);
        
        JLabel fecha1Label = setLabel("Ingrese la fecha inicial 'formato (dd/mm/yyyy)' : ");
        gbc.gridx = 0;
        gbc.gridy = 1;
        infoSedes.add(fecha1Label, gbc);
        JTextField fecha1TextField = new JTextField(20);
        this.fecha1 = fecha1TextField.getText();
		gbc.gridx = 0;
        gbc.gridy = 2;
        infoSedes.add(fecha1TextField, gbc);
        
        JLabel fecha2Label = setLabel("Ingrese la fecha final 'formato (dd/mm/yyyy)' : ");
        gbc.gridx = 0;
        gbc.gridy = 3;
        infoSedes.add(fecha2Label, gbc);
        JTextField fecha2TextField = new JTextField(20);
        this.fecha2 = fecha2TextField.getText();
		gbc.gridx = 0;
        gbc.gridy = 4;
        infoSedes.add(fecha2TextField, gbc);
        
        JLabel sedeDestinoLabel = setLabel("Sede: ");
        gbc.gridx = 0;
        gbc.gridy = 5;
        infoSedes.add(sedeDestinoLabel, gbc);
        ArrayList<Sede> posiblesSedes = empresa.getSedes();
		String[] sedes = new String[posiblesSedes.size()];
		for (int i = 0; i<posiblesSedes.size(); i++) {
			sedes[i] = posiblesSedes.get(i).getNombre();	
		}
        JComboBox<String> sedesBox = new JComboBox<>(sedes);
        JTextField sedeDestinoTextField = new JTextField(20);
        sedeDestinoTextField.setEditable(false); 
        sedesBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String seleccion = sedesBox.getSelectedItem().toString();
                sedeDestinoTextField.setText(seleccion);
                setSede(seleccion);
                
            }
        });
        gbc.gridx = 0;
        gbc.gridy = 6;
        infoSedes.add(sedesBox, gbc);

		gbc.gridx = 0;
        gbc.gridy = 7;
        infoSedes.add(sedeDestinoTextField, gbc);
        
        
        this.consultaButton = new JButton("Generar Traslado");
        consultaButton.addActionListener(this);
        consultaButton.setActionCommand(CONSULTA);
        consultaButton.setBackground(rojoOscuro);
        consultaButton.setForeground(Color.WHITE);
        consultaButton.setFont(fontBotones);
        gbc.gridx = 0;
        gbc.gridy = 8;
        infoSedes.add(consultaButton, gbc);
        
        consultaButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
                String sedeIng = sedeDestinoTextField.getText();
                String fecha1Ing = fecha1TextField.getText();
                String fecha2Ing = fecha2TextField.getText();
                
                setSede(sedeIng);
                setFecha1(fecha1Ing);
                setFecha2(fecha2Ing);
                
			}
        });
        
        total.add(infoSedes);
        add(total, BorderLayout.CENTER);
	}
	
	
	public String getFecha1() {
		return fecha1;
	}


	public String getFecha2() {
		return fecha2;
	}


	public String getSede() {
		return sede;
	}


	public void setFecha1(String fecha1) {
		this.fecha1 = fecha1;
	}


	public void setFecha2(String fecha2) {
		this.fecha2 = fecha2;
	}


	public void setSede(String sede) {
		this.sede = sede;
	}


	public JLabel setLabel(String palabra) {
		Font fontMonserratButtons = new Font("Monserrat", Font.PLAIN, 15);
		JLabel loginPrint = new JLabel();
		loginPrint.setText(palabra);
		loginPrint.setFont(fontMonserratButtons);
		loginPrint.setForeground(Color.BLACK);
		loginPrint.setHorizontalAlignment(JLabel.CENTER);
		return loginPrint;
	}


	@Override
	public void actionPerformed(ActionEvent e) {
		String comando = e.getActionCommand();
		if (comando.equals(CONSULTA)) {
			if (fecha1.length() == 0 ||fecha2.length() == 0|| sede.length() == 0) {
				JOptionPane.showMessageDialog(null, "Hay datos faltantes, no se pudo registrar.", "Info", JOptionPane.INFORMATION_MESSAGE);
			}
			else {
				String texto = "Disponibilidad sede: " + sede;
				Random random = new Random();
				texto += "\nSUV: " + random.nextInt(5);
				texto += "\nSedan: " + random.nextInt(5);
				texto += "\nLujoso: " + random.nextInt(5);
				texto += "\nVan: " + random.nextInt(5);
				texto += "\nCamioneta: " + random.nextInt(5);
				texto += "\nPequeño: " + random.nextInt(5);
				JOptionPane.showMessageDialog(null, texto, "Info", JOptionPane.INFORMATION_MESSAGE);
			}
			
		}
	}
}
