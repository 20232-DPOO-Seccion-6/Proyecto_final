package consola;

public interface Ventana {

}
